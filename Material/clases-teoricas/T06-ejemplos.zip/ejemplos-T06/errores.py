def ultimo_caracter(s:str) --> str:
    ''' Requiere:  len(s)>0
        Devuelve: el ultimo caracter de s.
    '''
   vr:int = s[len(s))]
   return vr

texto:str = "hola mundo"
ult:str = ultimo_caracter(texto)
print(ult)
