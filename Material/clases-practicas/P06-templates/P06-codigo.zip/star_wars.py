from typing import List #importante import para que listas ande bien

def nave_estelar_cercana(...) ...:
    
    '''
    completar docstring
    '''


    return



