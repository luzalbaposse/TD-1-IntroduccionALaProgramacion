import unittest

from star_wars import nave_estelar_cercana


class TestMision(unittest.TestCase):
    
	def test_...(self):
        

	def test_...(self):
        
        
unittest.main()

