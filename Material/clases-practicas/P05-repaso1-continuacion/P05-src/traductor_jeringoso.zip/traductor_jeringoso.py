###########################################################
####################### Ejercicio 2 #######################
###########################################################

from traductor_jeringoso_bib import traducir_a_jeringoso

print()
print('TRADUCTOR A JERINGOSO')
print('---------------------')
texto:str = input('Ingrese un texto: ')
print('Traducción: ', traducir_a_jeringoso(texto))
print()
