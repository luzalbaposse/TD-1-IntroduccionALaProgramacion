def inverso(x: float) -> float:
  ''' Requiere: x!=0
      Devuelve: el resultado de dividir 1 por x. 
  '''
  return 1/x


def cuadrado(n: int) -> int:
  ``` Requiere: Nada.
      Devuelve: el resutlado de elevar n al cuadrado.
  ```
  return n**n

n:int = 3
print("El cuadrado de", n, "es", cuardado(n))

n:int = "hola"
print("El cuadrado de", n, "es", cuadrado(n))

x:float = 2.0
print("El inverso de", x, "es", inverso(x)))

x:float = O.0
print("El inverso de", x, "es", inverso(X))

